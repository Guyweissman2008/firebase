package com.example.firebase;

import com.google.firebase.auth.FirebaseAuth;

public class FBRef {
    public static FirebaseAuth mAuth = FirebaseAuth.getInstance();
}
