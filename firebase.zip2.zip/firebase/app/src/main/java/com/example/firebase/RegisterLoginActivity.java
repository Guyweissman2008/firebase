package com.example.firebase;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;

public class RegisterLoginActivity extends AppCompatActivity {

    EditText emailEditText;
    EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initViews();
    }

    private void initViews() {
        emailEditText=findViewById(R.id.edittext_email);
        passwordEditText=findViewById(R.id.edittext_password);
    }

    public void register(View view) {

        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        FBRef.mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("guy","ok");
                            Toast.makeText(RegisterLoginActivity.this,"register isSuccessful:)",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(RegisterLoginActivity.this,WelcomeActivity.class));
                        } else {
                            Toast.makeText(RegisterLoginActivity.this,"register failed:(",Toast.LENGTH_LONG).show();
                            Log.d("guy",task.toString());

                        }
                        Log.d("guy","after");
                    }
                });
    }

    public void login(View view) {
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        FBRef.mAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(RegisterLoginActivity.this,"login isSuccessful:)",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(RegisterLoginActivity.this,WelcomeActivity.class));
                        } else {
                            Toast.makeText(RegisterLoginActivity.this,"login failed:(",Toast.LENGTH_LONG).show();
                            Log.d("AAA",task.toString());
                        }
                    }
                });
    }
}